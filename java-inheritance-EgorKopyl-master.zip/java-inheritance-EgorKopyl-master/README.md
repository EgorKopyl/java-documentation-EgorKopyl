# Практична робота "Реалізація успадкування"

Тварину для цієї практичної роботи я взяв лисицю(Fox)

<img src="https://github.com/ppc-ntu-khpi/java-inheritance-EgorKopyl/blob/master/images/Fox.jpg">

## Діаграма створена на основі EasyUML

<img src="https://github.com/ppc-ntu-khpi/java-inheritance-EgorKopyl/blob/master/images/DiagramFox.png">

## Результат роботи програми:

<img src="https://github.com/ppc-ntu-khpi/java-inheritance-EgorKopyl/blob/master/images/RunFox.png">
